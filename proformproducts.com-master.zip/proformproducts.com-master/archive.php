<?php
get_header();
?>
<h1>Newss</h1>
