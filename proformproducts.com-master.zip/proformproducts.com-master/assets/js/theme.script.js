jQuery(document).ready(function($){
   /**
   *  Handle Regions on the frontend
   */
   // $('div.region_btn').click( setSessionRegion );

   // function setSessionRegion(e) {
   //    e.preventDefault();
         
   //    var has_redirection = '';
   //    var data_region = $(this).data('region');
   //    var urlRedirection = $(this).find('a.elementor-button-link').attr('href');

   //    if ( $('#redirect_on_language').val() !== undefined ) {
   //       has_redirection = $('#redirect_on_language').val();
   //    } else {
   //       has_redirection = 'redirect';
   //    }

   //    $.ajax({
   //       type : "post",
   //       url : ajax_obj.url,
   //       data : {
   //          action: "handle_region_on_click",
   //          region: $(this).data('region')
   //       },
   //       success: function(response) {
   //          if ( has_redirection === 'redirect' ) {
   //             window.location.href = urlRedirection;
   //          } else {
   //             window.location.reload(true);
   //          }
   //       }
   //    })
   // }
   // Set widths for variation information to align based on longest item
   // Align tables with the specified class so that all columns line up across tables.

   // Change session value when region flag is clicked
   $('.region_btn a').click( changeContent );

   function changeContent(e) {
     e.preventDefault();
       var urlRedirection = $(this).attr('href');
       var setRegion;
       if ( urlRedirection.indexOf("ca/en") !== -1 ){
         setRegion = "ca-en";
       } else if( urlRedirection.indexOf("ca/fr") !== -1 ){
         setRegion = "ca-fr";
       } else if( urlRedirection.indexOf("us/sp") !== -1 ){
         setRegion = "us-sp";
       } else {
         setRegion = "us-en";
       }
 
       $.ajax({
         type : "post",
         //url : ajax_obj.url,
         data : {
             action: "handle_region_on_click",
             region: setRegion
         },
         success: function(response) {
           //alert("True"); 
           window.location.href = urlRedirection;
         }
       })
   }

   // Find the max width of each column across all tables. Only look at 'th' or 'td' cells in the first row of each table.
   var col_widths = [];
   $(".variation-details-table").each(function(index, element) {
     $(element).find("tr:first th, tr:first td").each(function(index2, element2) {
         col_widths[index2] = Math.max(col_widths[index2] || 0, $(element2).width());
     });
   });

   // Set each column in each table to the max width of that column across all tables.
   $(".variation-details-table").each(function(index, element) {
     $(element).find("tr:first th, tr:first td").each(function(index2, element2) {
         $(element2).width(col_widths[index2]);
     });
   });
});

function openNav() {
  document.getElementById("sidebar-nav").style.width = "320px";
}

/* Set the width of the side navigation to 0 */
function closeNav() {
  document.getElementById("sidebar-nav").style.width = "0";
} 