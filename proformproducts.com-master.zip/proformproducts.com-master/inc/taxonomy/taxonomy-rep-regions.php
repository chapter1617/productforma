<?php
add_action( 'init', 'representatives_regions', 0 );
 
function representatives_regions() {
 
  $labels = array(
    'name' => _x( 'Regions', 'taxonomy general name' ),
    'singular_name' => _x( 'Region', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Regions' ),
    'all_items' => __( 'All Regions' ),
    'parent_item' => __( 'Parent Type' ),
    'parent_item_colon' => __( 'Parent Type:' ),
    'edit_item' => __( 'Edit Type' ), 
    'update_item' => __( 'Update Type' ),
    'add_new_item' => __( 'Add New Type' ),
    'new_item_name' => __( 'New Type Name' ),
    'menu_name' => __( 'Regions' ),
  );  
 
  register_taxonomy('rep-region',
    array('representatives'), 
      array(
        'public'            => true,
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
        'show_in_quick_edit'=> true,
        'publicly_queryable'=> true,
        'rest_base'         => 'rep-regions',
        'query_var'         => true,
        'rewrite'           => array( 'slug' => 'rep-region' ),
    )
    );
}