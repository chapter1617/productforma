<?php 

add_action( 'init', 'custom_resources_taxonomy_types', 0 );
 
function custom_resources_taxonomy_types() {
 
  $labels = array(
    'name' => _x( 'Types of Resources', 'taxonomy general name' ),
    'singular_name' => _x( 'Type of Resource', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Types of Resources' ),
    'all_items' => __( 'All Types of Resources' ),
    'parent_item' => __( 'Parent Type' ),
    'parent_item_colon' => __( 'Parent Type:' ),
    'edit_item' => __( 'Edit Type' ), 
    'update_item' => __( 'Update Type' ),
    'add_new_item' => __( 'Add New Type' ),
    'new_item_name' => __( 'New Type Name' ),
    'menu_name' => __( 'Types of Resources' ),
  ); 	
 
  register_taxonomy('type',
  	array('resources'), 
  		array(
  			'public'			      => true,
		    'hierarchical' 		  => true,
		    'labels' 			      => $labels,
		    'show_ui' 			    => true,
		    'show_admin_column' => true,
		    'show_in_rest' 		  => true,
		    'show_in_quick_edit'=> true,
        'publicly_queryable'=> true,
        'rest_base'         => 'types',
		    'query_var' 		    => true,
		    'rewrite' 			    => array( 'slug' => 'type' ),
	  )
  	);
}