<?php 
	if(!is_single()): 
		global $more; 
		$more = 0;
	endif;

	$brand = get_the_terms( get_the_ID(), 'brands' )[0];
	$region_brands = get_field( 'region', $brand );
	$region = strtoupper( $_SESSION['region'] );
?>


<?php foreach ($region_brands as $key => $value):
	if ( $value = $region ): ?>
		
		<?php $product_name = get_field('product_names_group')[$_SESSION['region'].'_product_name']; ?>

		<article id="post-<?php the_ID(); ?>" <?php post_class("post clearfix"); ?>>

			<time datetime="<?php the_time('o-m-d') ?>" class="post-date" pubdate><?php the_time('M j, Y') ?></time>
			
			<h1 class="post-title"><a href="<?php the_permalink(); ?>"><?php echo $product_name; ?></a></h1>

			<p class="post-meta"> 
				<span class="post-author"><i class="fa fa-user"></i>&nbsp;&nbsp;<?php the_author_posts_link() ?></span>
				<span class="post-category"><i class="fa fa-folder"></i>&nbsp;&nbsp;<?php the_category(', ') ?></span>
				<?php the_tags(' <span class="post-tag"><i class="fa fa-tags"></i>&nbsp;&nbsp;', ', ', '</span>'); ?>
				<?php if ( comments_open() ) : ?>
					<span class="post-comment"><i class="fa fa-comments"></i>&nbsp;&nbsp;<?php comments_popup_link( __( '0 Comment', 'themify' ), __( '1 Comment', 'themify' ), __( '% Comments', 'themify' ) ); ?></span>
				<?php endif; //post comment ?>
			</p>
				
			<?php the_content(); ?>
			
			<?php edit_post_link(__('Edit', 'themify'), '[', ']'); ?>
			
		</article>

	<?php endif; ?>
<?php endforeach; ?>
<!-- /.post -->