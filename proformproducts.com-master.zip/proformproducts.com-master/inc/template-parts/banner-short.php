<section class="short-banner">
	<div class="banner-content">
		<h1><?php echo get_the_title(); ?></h1>
		<?php
			if(is_single() and 'resources' == get_post_type()) {
				echo '// SDS Resource';
			}
		?>
	</div>
</section>