<?php
$obj = get_queried_object();
if(is_singular('products')) {
	$cats = get_terms(array(
		'taxonomy' 		=> 'category',
		'object_ids' 	=> get_the_ID(),
		'order'			=> 'DESC'
	));
	$brands = get_terms(array(
		'taxonomy' 		=> 'brands',
		'object_ids' 	=> get_the_ID(),
		'order'			=> 'DESC'
	));
	// echo '<pre>';
	// var_dump($cats);
	// echo '</pre>';
	$currentCatID = $cats[0]->term_id;
	if($cats) {
		$numOfCats = count($cats);
	} else {
		$numOfCats = 0;
	}
	if($numOfCats >= 2) {
		foreach($cats as $cat) {
			if($cat->parent == 0) {
				// is parent
				$category_banner_color = get_field('category_color', 'category_'.$cat->term_id);
				if($_SESSION['region'] == 'ca-fr') {
					$french_cat_name = get_field('french_category_name', 'category_'.$cat->term_id);
					$product_main_cat = $french_cat_name;
					$parent = '<a href="'.get_category_link($cat->term_id).'">'.$french_cat_name.'</a><i class="fas fa-chevron-right"></i>';
				}
				elseif($_SESSION['region'] == 'us-sp') {
					$spanish_cat_name = get_field('spanish_category_name', 'category_'.$cat->term_id);
					$product_main_cat = $spanish_cat_name;
					$parent = '<a href="'.get_category_link($cat->term_id).'">'.$spanish_cat_name.'</a><i class="fas fa-chevron-right"></i>';
				}
				else {
					$product_main_cat = $cat->name;	
					$parent = '<a href="'.get_category_link($cat->term_id).'">'.$cat->name.'</a><i class="fas fa-chevron-right"></i>';
				}
			}
			else {
				$child_category_banner_color = get_field('category_color', 'category_'.$cat->term_id);
				if($_SESSION['region'] == 'ca-fr') {
					$french_cat_name = get_field('french_category_name', 'category_'.$cat->term_id);
					$product_main_cat = $french_cat_name;
					$child = '<a href="'.get_category_link($cat->term_id).'">'.$french_cat_name.'</a>';
				}
				elseif($_SESSION['region'] == 'us-sp') {
					$spanish_cat_name = get_field('spanish_category_name', 'category_'.$cat->term_id);
					$product_main_cat = $spanish_cat_name;
					$child = '<a href="'.get_category_link($cat->term_id).'">'.$spanish_cat_name.'</a>';
				}
				else {
					$product_main_cat = $cat->name;	
					$child = '<a href="'.get_category_link($cat->term_id).'">'.$cat->name.'</a>';
				}
			}
		}
	}
	elseif($numOfCats == 0) {
		$parent = '';
	}
	else {
		$parent = '<a href="'.get_category_link($cats[0]->term_id).'">'.$cats[0]->name.'</a>';
		$category_banner_color = get_field('category_color', 'category_'.$cats[0]->term_id);
		if($_SESSION['region'] == 'ca-fr') {
			$french_cat_name = get_field('french_category_name', 'category_'.$cats[0]->term_id);
			$product_main_cat = $french_cat_name;
			$parent = '<a href="'.get_category_link($cats[0]->term_id).'">'.$french_cat_name.'</a>';
		}
		elseif($_SESSION['region'] == 'us-sp') {
			$spanish_cat_name = get_field('spanish_category_name', 'category_'.$cats[0]->term_id);
			$product_main_cat = $spanish_cat_name;
			$parent = '<a href="'.get_category_link($cats[0]->term_id).'">'.$spanish_cat_name.'</a>';
		}
		else {
			$product_main_cat = $cats[0]->name;
			$parent = '<a href="'.get_category_link($cats[0]->term_id).'">'.$cats[0]->name.'</a>';
		}
	}
	// if($category_banner_color) {
	// 	if($brands[0]->term_id == 19 or $brands[0]->term_id == 18 ) {
	// 		$category_banner_color = $category_banner_color;
	// 	}
	// 	elseif($brands[0]->term_id == 20 or $brands[0]->term_id == 21) {
	// 		$category_banner_color = $category_banner_color;	
	// 	}
	// 	else {
	// 		$category_banner_color = '#ed1c24';
	// 	}
	// }
	if($child_category_banner_color) {
		$category_banner_color = $child_category_banner_color; 
	}
	// else {
	// 	$category_banner_color = '#ed1c24';
	// }
}
elseif(is_category()) {
	$currentCat = get_category(get_query_var('cat'));
	$cats = get_terms(array(
		'taxonomy' 		=> 'category',
		'include' 	=> array ($currentCat->term_id),
		'hide_empty' => true,
	));
	$currentCatID = $currentCat->term_id;
	$args = array (
		'post_type'		=> 'products',
		'numberposts'	=> -1,
		'category'		=> $currentCatID,
		'orderby'		=> 'name',
		'order'			=> 'ASC',
	);
	if($_SESSION['region'] == 'ca-fr') {
		$french_cat_name = get_field('french_category_name', 'category_'.$cats[0]->term_id);
		$category_name_translated = $french_cat_name;
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$spanish_cat_name = get_field('spanish_category_name', 'category_'.$cats[0]->term_id);
		$category_name_translated = $spanish_cat_name;
	}
	else {
		$category_name_translated = $cats[0]->name;	
	}
	$categoryProducts = get_posts($args);
	$category_banner_color = get_field('category_color', 'category_'.$cats[0]->term_id);
	if($category_banner_color) {
		$category_banner_color = $category_banner_color;
	}
	else {
		$category_banner_color = '#ed1c24';
	}
	$banner_height = 'height: 200px;';
}
elseif(is_tax('brands')) {
	$category_banner_color = get_field('brand_color', $obj);
	if($category_banner_color) {
		$category_banner_color = $category_banner_color;
	} else {
		$category_banner_color = '#ed1c24';
	}
}
elseif(is_post_type_archive('products')) {
	$category_banner_color = '#ed1c24';
}
else {
	
}
// $currentCatID = get_queried_object()->term_id;
// $bannerImage = get_field('banner_image', $cats[0]->taxonomy.'_'.$currentCatID );
// if($bannerImage) {
// 	$bannerImage = 'background-image: url('.$bannerImage['url'].');';
// }
// else {
// 	$bannerImage = '';
// }
if($_SESSION['region'] == 'ca-fr') {
	$products_translation = 'Des produits';
	$all_categories = 'toutes catégories';
}
elseif($_SESSION['region'] == 'us-sp') {
	$products_translation = 'Productos';
	$all_categories = 'todas las categorias';
}
else {
	$products_translation = 'Products';	
	$all_categories = 'All Categories';
}
?>
<div class="banner" style="background-color:<?php echo $category_banner_color; ?>;">
	<div class="tall-banner">
		<div class="breadcrumbs">
			<?php
				if(is_singular('products')) {
					echo '<a href="'.get_bloginfo('url').'/products">'.$products_translation.'</a>' . '<i class="fas fa-chevron-right"></i>';
					echo $parent;
					if( isset($child)) {
						echo $child;
					}
				}
				elseif(is_category()) { 
					echo '<a href="'.get_bloginfo('url').'/products">'.$all_categories.'</a>' . '<i class="fas fa-chevron-right"></i>'; 
					if($cats[0]->parent > 0) {
						if($_SESSION['region'] == 'ca-fr') {
							$translated_cat_name = get_field('french_category_name', 'category_'.get_term($cats[0]->parent)->term_id);
						} elseif($_SESSION['region'] == 'us-sp') {
							$translated_cat_name = get_field('spanish_category_name', 'category_'.get_term($cats[0]->parent)->term_id);
						} else {
							$translated_cat_name = get_term($cats[0]->parent)->name;
						}
						if($translated_cat_name) {
							$translated_cat_name = $translated_cat_name;
						} else {
							$translated_cat_name = get_term($cats[0]->parent)->name;
						}
						echo '<a href="'.get_category_link(get_term($cats[0]->parent)->term_id).'">'.$translated_cat_name.'</a>' . '<i class="fas fa-chevron-right"></i>';
					}
				}
				elseif(is_tax()) {
					echo '<a href="'.get_bloginfo('url').'/products">'.$products_translation.'</a>' . '<i class="fas fa-chevron-right"></i>'; 
					echo '<a href="'.get_category_link($obj->term_id).'">'.$obj->name.'</a>';
				}
				elseif(is_post_type_archive('products')) {

				}
				else {
					
				}
			?>
		</div>
		<?php
		if(is_category()) {
			echo '<div class="banner-footer">';
				echo '<h1>'.$category_name_translated.'</h1>';
				echo '<div class="category-product-count">// <span>'.count($categoryProducts).'</span> '.strtolower($products_translation).'</div>';
			echo '</div>';
		}
		elseif(is_post_type_archive('products')) {
			echo '<div class="banner-footer">';
				echo '<h1>'.$products_translation.'</h1>';
				// echo '<div class="category-product-count">// <span>'.count($categoryProducts).'</span> '.strtolower($products_translation).'</div>';
				$countPosts = $wp_the_query->post_count;
				echo '<div class="category-product-count">// <span>'.$countPosts.' '.strtolower($products_translation).'</span></div>';
			echo '</div>';
		}
		elseif(is_tax()) {
			echo '<div class="banner-footer">';
				echo '<h1>'.$obj->name.' '.$products_translation.'</h1>';
				$countPosts = $wp_the_query->post_count;
				echo '<div class="category-product-count">// <span>'.$countPosts.'</span> '.strtolower($products_translation).'</div>';
			echo '</div>';
		}
		else {

		}
		?>
	</div>
</div>