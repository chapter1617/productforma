<div class="right-sidebar">
	<?php
		$categories_sidebar = get_terms(array(
			'taxonomy'	 => 'category',
			'hide_empty' => true,
			'parent' 	 => 0,
			'exclude'	 => 1,
		));
		$brands_sidebar = get_terms( array (
			'taxonomy'	 => 'brands',
			'orderby'	 => 'slug',
			'hide_empty' => true,
			'parent' 	 => 0,
			'number'	 => 0,
		));
	?>
		
	<h2>Filter Products //</h2>

	<h3>Categories:</h3>

	<ul class="proform_products_categories">
		<?php
			foreach ($categories_sidebar as $cat) {
				switch ($_SESSION['region']) {
					case 'ca-en':
						$cat_name = get_field('english_name_us_en', 'category_' . $cat->term_id);
						break;
					case 'ca-fr':
						$cat_name = get_field('french_category_name', 'category_' . $cat->term_id);
						break;
					case 'us-en':
						$cat_name = get_field('english_name_us_en', 'category_' . $cat->term_id);
						break;
					case 'us-sp':
						$cat_name = get_field('spanish_category_name', 'category_' . $cat->term_id);
						break;
				}

				$cat_name = $cat_name ? $cat_name : $cat->name;

				echo '<li><label><input type="checkbox" class="proform_select_term proform_select_category" value="' . $cat->term_id . '" /> ' . $cat_name . '</label></li>';
			}
		?>
	</ul>

	<h3>Brands:</h3>

	<ul class="proform_products_brands">
		<?php
			foreach ($brands_sidebar as $brand) {
				$regions = get_field('region', 'term_' . $brand->term_id);

				foreach ($regions as $region) {
					if (in_array(strtoupper($_SESSION['region']), $region)) {
						echo '<li><label><input type="checkbox" class="proform_select_term proform_select_brand" value="' . $brand->term_id . '" /> ' . $brand->name . '</label></li>';
					}
				}
			}
		?>
	</ul>
</div>

<script>
	jQuery(document).ready(function($){

		$('.proform_select_term').on('click', function(){
			var brands = [];
			var categories = [];

			$(".proform_select_brand:checked").each(function() { 
                brands.push($(this).val());
            });

            $(".proform_select_category:checked").each(function() { 
                categories.push($(this).val());
            });

            setTimeout(function() {
				$.ajax({
					type: 'POST', // POST
					url: '<?php echo admin_url( 'admin-ajax.php' ) ?>',
					data: {
						action: "get_ajax_products_by_terms",
	            		brands: brands,
	            		categories: categories
					},
					beforeSend:function(xhr){
						$('.proform_products_list').text('Processing...');
					},
					success:function(data){
						$('.proform_products_list').replaceWith(data);
					}
				});
            }, 1000);
		})

	});
</script>