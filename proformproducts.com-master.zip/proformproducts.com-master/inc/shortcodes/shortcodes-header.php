<?php

/**
* Output Main Menu in Header
*/
function output_custom_main_menu ( $atts ) {
  $menu_slug = $_SESSION['region'] . '-nav';
  $menu = wp_get_nav_menu_items( $menu_slug );

  if ( $menu ) {
    $menu_list  = '<nav class="custom_main_menu"><ul>';
          
    foreach( $menu as $menu_item ) {
      $menu_list .= '<li class="menu-item"><a href="' . $menu_item->url . '">' . $menu_item->title . '</a></li>';
    }

    $menu_list .= '</ul></nav>';
  } else {
    $menu_list = '<!-- no menu defined in location -->';
  }
     
  return $menu_list;
}
add_shortcode( 'custom-main-menu', 'output_custom_main_menu' );


/**
* Output Main Menu in Header
*/
function output_custom_flag () {
	$flag_resource = 'usa';

	if ( strpos($_SESSION['region'], 'ca') !== false ) {
		$flag_resource = 'ca';
	}

	ob_start(); ?>

	<a class="open_region_selector" href="#">
		<img class="custom_shortcode-flag" src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo $flag_resource; ?>-flag.png" />
	</a>

	<script>
		jQuery(document).ready(function(){
			var region_default = '<?php echo $_SESSION['region_default'] ?>';

			if ( region_default !== '' ) {
				setTimeout(function(){
					jQuery('.open_region_selector').click();
				}, 4000);
			}

			console.log( 'region_default: ', region_default );
		});
	</script>

	<?php $output_flag = ob_get_clean();

	return $output_flag;
}
add_shortcode( 'custom-flag', 'output_custom_flag' );

// Show Selected Region
function show_admin_selected_region() {
	$adminID = get_current_user_id();
  if($adminID == 1) {
  	echo $_SESSION['region'];
  }
}
add_shortcode('show-region-text', 'show_admin_selected_region');

function redirect_logo_to_brand_page() {
	if($_SESSION['region'] == 'ca-en') {
        $ii = 13397;
		$id = 9316; // Pro Form Canada EN
	}
	elseif ($_SESSION['region'] == 'ca-fr') {
		$ii = 13397;
        $id = 10465; // Pro Form Canada
	}
	elseif ($_SESSION['region'] == 'us-en') {
		$ii = 13396;
        $id = 9452; // Pro Form USA
	}
	elseif ($_SESSION['region'] == 'us-sp') {
		$ii = 13396;
        $id = 10462; // Pro Form USA
	}
	else {
        $ii = 13396;
		$id = 9316;
	}
	return '<a href="'.get_permalink($id).'"><img class="website-logo" src="'.wp_get_attachment_url($ii).'" alt="Pro Form Products Ltd."></a>';
}
add_shortcode('redirect-logo-url','redirect_logo_to_brand_page');

// Translations
function other_brands_markets_translations() {
	$title = get_field('field_5f0f4dfe1d503', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['french'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['spanish'];
    } else {
    	$trans = $title['english'];
    }
    return $trans;
}
add_shortcode('other-brands-translation', 'other_brands_markets_translations');

function find_distributor_translations() {
	$title = get_field('field_5f0f501d4eafe', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['french'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['spanish'];
    } else {
    	$trans = $title['english'];
    }
    return $trans;
}
add_shortcode('find-distributor-translation', 'find_distributor_translations');

function contact_us_translations() {
	$title = get_field('contact_us_translation_text_group_two', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['french'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['spanish'];
    } else {
    	$trans = $title['english'];
    }
    return $trans;
}
add_shortcode('contact-us-translation', 'contact_us_translations');

function contact_us_link() {
    if($_SESSION['region'] == 'ca-fr') {
        $link = get_permalink(14812);
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
        $link = get_permalink(14810);
    } else {
        $link = get_permalink(2);
    }
    return $link;
}
add_shortcode('contact-us-link', 'contact_us_link');

function catalog_translations() {
    $title = get_field('field_5f0f503d4eb02', 'option');
    if($_SESSION['region'] == 'ca-fr') {
        $trans = $title['french'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
        $trans = $title['spanish'];
    } else {
        $trans = $title['english'];
    }
    return $trans;
}
add_shortcode('catalog-translation', 'catalog_translations');

function contact_us_translations_footer() {
	$title = get_field('field_5f0f4f2b4eaea', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['french'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['spanish'];
    } else {
    	$trans = $title['english'];
    }
    return $trans;
}
add_shortcode('contact-us-translation-footer', 'contact_us_translations_footer');

function phone_translation() {
	$title = get_field('field_5f0f4f954eaee', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['french'].': 905-878-4990';
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['spanish'].': 905-878-4990';
    } else {
    	$trans = $title['english'].': 905-878-4990';
    }
    return $trans;
}
add_shortcode('phone-translation', 'phone_translation');

function toll_free_translation() {
	$title = get_field('field_5f0f4fc14eaf2', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['french'].': 1-800-387-7981';
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['spanish'].': 1-800-387-7981';
    } else {
    	$trans = $title['english'].': 1-800-387-7981';
    }
    return $trans;
}
add_shortcode('tollfree-translation', 'toll_free_translation');

function fax_translation() {
	$title = get_field('field_5f0f4fe14eaf6', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['french'].': 905-878-1189';
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['spanish'].': 905-878-1189';
    } else {
    	$trans = $title['english'].': 905-878-1189';
    }
    return $trans;
}
add_shortcode('fax-translation', 'fax_translation');

function email_translation() {
	$title = get_field('field_5f0f4ffe4eafa', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['french'].': info@proformproducts.com';
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['spanish'].': info@proformproducts.com';
    } else {
    	$trans = $title['english'].': info@proformproducts.com';
    }
    return $trans;
}
add_shortcode('email-translation', 'email_translation');