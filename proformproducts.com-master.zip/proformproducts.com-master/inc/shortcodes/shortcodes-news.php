<?php
function news_related_products() {
	// related products
	$rp = get_field('related_products');
	// related product settings show/hide
	$rps = get_field('related_product_settings');
	// echo '<pre>';
	// var_dump($rp);
	// echo '</pre><br><br><pre>';
	// var_dump($rps);
	// echo '</pre>';
	if($rp) {
		$count = count($rp);
		if($count == 1) {
			$s = '';
		}
		else {
			$s = 's';
		}
		$output = '<h2>Related Product'. $s .'</h2>';
		foreach($rp as $r) {
			$output .= '<div class="news-related-product-container">';
			if($rps and in_array('image', $rps)) {
				$img = get_field('main_image', $r->ID);
				$varImg = get_field('product_details_image', $r->ID);
				$size = 'medium';
				if($img) {
					$output .= '<a href="'.get_permalink($r->ID).'">';
					$output .= wp_get_attachment_image($img['ID'], $size);
					$output .= '</a>';
				} 
				elseif($varImg) {
					$output .= '<a href="'.get_permalink($r->ID).'">';
					$output .= wp_get_attachment_image($img[0]['ID'], $size);
					$output .= '</a>';
				}
				else {

				}
			}
			if($rps and in_array('product-name', $rps)) {
				$output .= '<h3>'.$r->post_title.'</h3>';
			}
			if($rps and in_array('description', $rps)) {
				$description = get_field('descriptions_description_ca_en', $r->ID);
				if($description)
				$output .= '<p class="description">'.$description.'</p>';
			}
			if($rps and in_array('part-number', $rps)) {
				$ptn = get_field('admin_product_number', $r->ID);
				if($ptn) {
					$output .= '<p class="part-number">Part #: <span>'.$ptn.'</span></p>';
				}
			}
			if($rps and in_array('case-quantity', $rps)) {
				$case = get_field('product_details', $r->ID);
				$output .= '<p class="case-qty">Qty: <span>'.$case[0]['cs_qt'].'/case</span></p>';
			}
			$output .= '<a class="related-product-button" href="'.get_permalink($r->ID).'">See Product Page</a>';
			$output .= '</div>';
		}
	} else {
		$output = '';
	}
	return $output;
}
add_shortcode('news-related-products','news_related_products');

// get recent news posts for region
function get_recent_news_posts() {
	$news = get_posts(
		array (
			'post_type' 	=> 'post',
			'numberposts' 	=> 8,
			'orderby'		=> 'date',
			'order'			=> 'DESC',
		)
	);
	if($_SESSION['region'] == 'ca-fr') {
		$title = 'Nouvelles récentes';
		$none = 'Aucune nouvelle récente';
	} elseif($_SESSION['region'] == 'us-sp') {
		$title = 'Noticias recientes';
		$none = 'Sin noticias recientes';
	} else {
		$title = 'Recent News';
		$none = 'No recent news';
	}
	$output = '<div class="elementor-widget-wp-widget-recent-posts">';
	$output .= '<h5>'.$title.'</h5>';
	if($news) {
		$output .= '<ul>';
		// var_dump($news);
		foreach($news as $n) {
			$region = get_field('region', $n->ID);
			if(in_array_r(strtoupper($_SESSION['region']), $region)) {
				$output .= '<li><a href="'.get_permalink($n->ID).'">'. get_the_title($n->ID).'</a></li>';
			}
		}
		$output .= '</ul>';
	} else {
		$output .= $none;
	}
	$output .= '</div>'; 
	return $output;
}
add_shortcode('recent-news-posts', 'get_recent_news_posts');