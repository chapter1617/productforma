<?php
function catalog_pdfs() {
    $us_en_catalogs = get_field('us_english_catalog');
    $us_sp_catalogs = get_field('us_spanish_catalog');
    $ca_en_catalogs = get_field('ca_english_catalog');
    $ca_fr_catalogs = get_field('ca_french_catalog');
    $output = '<div class="resource-container catalog-container">';
        if($_SESSION['region'] == 'us-en') {
            if($us_en_catalogs) {
                if($us_en_catalogs['low_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$us_en_catalogs['low_res'].'"><i class="fad fa-file-pdf small-pdf"></i><span>'.$us_en_catalogs['pdf_namelabel'].'</span></a></div>';    
                }
                if($us_en_catalogs['medium_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$us_en_catalogs['medium_res'].'"><i class="fad fa-file-pdf medium-pdf"></i><span>'.$us_en_catalogs['pdf_namelabel'].'</span></a></div>';
                }
                if($us_en_catalogs['high_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$us_en_catalogs['high_res'].'"><i class="fad fa-file-pdf large-pdf"></i><span>'.$us_en_catalogs['pdf_namelabel'].'</span></a></div>';
                }
                if($us_en_catalogs['interactive_catalog_embed_code']) {
                    $output .= $us_en_catalogs['interactive_catalog_embed_code'];
                }    
            }
            else {
                $output .= 'Our catalogs are not currently online for this region/language.';
            }
        } elseif ( $_SESSION['region'] == 'us-sp' ) {
            if($us_sp_catalogs) {
                if($us_sp_catalogs['low_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$us_sp_catalogs['low_res'].'"><i class="fad fa-file-pdf small-pdf"></i><span>'.$us_sp_catalogs['pdf_namelabel'].'</span></a></div>';    
                }
                if($us_sp_catalogs['medium_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$us_sp_catalogs['medium_res'].'"><i class="fad fa-file-pdf medium-pdf"></i><span>'.$us_sp_catalogs['pdf_namelabel'].'</span></a></div>';
                }
                if($us_sp_catalogs['high_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$us_sp_catalogs['high_res'].'"><i class="fad fa-file-pdf large-pdf"></i><span>'.$us_sp_catalogs['pdf_namelabel'].'</span></a></div>';
                }
                if($us_sp_catalogs['interactive_catalog_embed_code']) {
                    $output .= $us_sp_catalogs['interactive_catalog_embed_code'];
                }    
            }
            else {
                $output .= 'Nuestros catálogos no están actualmente en línea para esta región / idioma.';
            }
        } elseif ( $_SESSION['region'] == 'ca-en' ) {
            if($ca_en_catalogs) {
                if($ca_en_catalogs['low_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$ca_en_catalogs['low_res'].'"><i class="fad fa-file-pdf small-pdf"></i><span>'.$ca_en_catalogs['pdf_namelabel'].'</span></a></div>';    
                }
                if($ca_en_catalogs['medium_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$ca_en_catalogs['medium_res'].'"><i class="fad fa-file-pdf medium-pdf"></i><span>'.$ca_en_catalogs['pdf_namelabel'].'</span></a></div>';
                }
                if($ca_en_catalogs['high_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$ca_en_catalogs['high_res'].'"><i class="fad fa-file-pdf large-pdf"></i><span>'.$ca_en_catalogs['pdf_namelabel'].'</span></a></div>';
                }
                if($ca_en_catalogs['interactive_catalog_embed_code']) {
                    $output .= $ca_en_catalogs['interactive_catalog_embed_code'];
                }    
            }
            else {
                $output .= 'Our catalogs are not currently online for this region/language.';
            }
        } elseif ( $_SESSION['region'] == 'ca-fr' ) {
            if($ca_fr_catalogs) {
                if($ca_fr_catalogs['low_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$ca_fr_catalogs['low_res'].'"><i class="fad fa-file-pdf small-pdf"></i><span>'.$ca_fr_catalogs['pdf_namelabel'].'</span></a></div>';    
                }
                if($ca_fr_catalogs['medium_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$ca_fr_catalogs['medium_res'].'"><i class="fad fa-file-pdf medium-pdf"></i><span>'.$ca_fr_catalogs['pdf_namelabel'].'</span></a></div>';
                }
                if($ca_fr_catalogs['high_res']) {
                    $output .= '<div class="resource-file"><a target="_blank" href="'.$ca_fr_catalogs['high_res'].'"><i class="fad fa-file-pdf large-pdf"></i><span>'.$ca_fr_catalogs['pdf_namelabel'].'</span></a></div>';
                }
                if($ca_fr_catalogs['interactive_catalog_embed_code']) {
                    $output .= $ca_fr_catalogs['interactive_catalog_embed_code'];
                }    
            }
            else {
                $output .= 'Nos catalogues ne sont pas actuellement en ligne pour cette région/langue.';
            }
        } else {
            
        }
    $output .= '</div>';
    return $output;
}
add_shortcode('show-catalogs', 'catalog_pdfs');