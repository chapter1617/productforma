<?php

function main_search_form() {
	$output = '<form role="search" method="get" class="search-form main-search-form" action="'.site_url( 'search-results/' ).'">';
	    $output .= '<label>';
	        $output .= '<span class="screen-reader-text">'._x( 'Search for:', 'label' ).'</span>';
	        if(isset( $_GET['searchwp'] )) {
	        	$value = esc_attr( $_GET['searchwp'] );
	        } else {
	        	$value = '';
	        }
	        $placeholder = get_field('field_5f0d29e1c5e4b', 'option');
	        if($_SESSION['region'] == 'ca-fr') {
	        	$trans = 'Rechercher des produits, des ressources, etc.';
	        } elseif ( $_SESSION['region'] == 'us-sp' ) {
	        	$trans = 'Buscar productos, recursos, etc.';
	        } else {
	        	$trans = 'Search Products, Resources, etc.';
	        }
	        $output .= '<input 
	        	type="search" 
		        class="search-field" 
		        name="searchwp"
		        placeholder="'.esc_attr_x( $trans, 'placeholder' ).'" 
		        value="'.$value.'" 
		        title="'.esc_attr_x( 'Search for:', 'label' ).'"
	        />';
	    $output .= '</label>';
	    $output .= '<input type="submit" class="search-submit supplemental-search-submit" value="'.esc_attr_x( '&#xf002;', 'submit button' ).'" />';
	$output .= '</form>';
	return $output;
}
add_shortcode('main-search-form', 'main_search_form');

function distributor_search_form() {
	$output = '<form role="search" method="get" class="search-form supplemental-search-form" action="'.site_url( 'distributor-search-results/' ).'">';
	    $output .= '<label>';
	        $output .= '<span class="screen-reader-text">'._x( 'Search for:', 'label' ).'</span>';
	        if(isset( $_GET['searchwp'] )) {
	        	$value = esc_attr( $_GET['searchwp'] );
	        } else {
	        	$value = '';
	        }
	        $placeholder = get_field('field_5f0d29e1c5e4b', 'option');
	        if($_SESSION['region'] == 'ca-fr') {
	        	$trans = $placeholder['distributors_search_placeholder_text_fr'];
	        } elseif ( $_SESSION['region'] == 'us-sp' ) {
	        	$trans = $placeholder['distributors_search_placeholder_text_sp'];
	        } else {
	        	$trans = $placeholder['distributors_search_placeholder_text_en'];
	        }
	        $output .= '<input 
	        	type="search" 
		        class="search-field" 
		        name="searchwp"
		        placeholder="'.esc_attr_x( $trans, 'placeholder' ).'" 
		        value="'.$value.'" 
		        title="'.esc_attr_x( 'Search for:', 'label' ).'"
	        />';
	    $output .= '</label>';
	    $output .= '<input type="submit" class="search-submit supplemental-search-submit" value="'.esc_attr_x( '&#xf002;', 'submit button' ).'" />';
	$output .= '</form>';
	return $output;
}
add_shortcode('distributor-search', 'distributor_search_form');

function resource_search_form() {
	$output = '<form role="search" method="get" class="search-form supplemental-search-form" action="'.site_url( 'resource-search-results/' ).'">';
	    $output .= '<label>';
	        $output .= '<span class="screen-reader-text">'._x( 'Search for:', 'label' ).'</span>';
	        if(isset( $_GET['searchwp'] )) {
	        	$value = esc_attr( $_GET['searchwp'] );
	        } else {
	        	$value = '';
	        }
	        $placeholder = get_field('field_5f0d0d377ae7d', 'option');
	        if($_SESSION['region'] == 'ca-fr') {
	        	$trans = $placeholder['search_placeholder_text_fr'];
	        } elseif ( $_SESSION['region'] == 'us-sp' ) {
	        	$trans = $placeholder['search_placeholder_text_sp'];
	        } else {
	        	$trans = $placeholder['search_placeholder_text_en'];
	        }
	        $output .= '<input 
	        	type="search" 
		        class="search-field" 
		        name="searchwp"
		        placeholder="'.esc_attr_x( $trans, 'placeholder' ).'" 
		        value="'.$value.'" 
		        title="'.esc_attr_x( 'Search for:', 'label' ).'"
	        />';
	    $output .= '</label>';
	    $output .= '<input type="submit" class="search-submit supplemental-search-submit" value="'.esc_attr_x( '&#xf002;', 'submit button' ).'" />';
	$output .= '</form>';
	return $output;
}
add_shortcode('resource-search', 'resource_search_form');