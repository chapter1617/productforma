<?php

function archive_products_output() {
	$include_args = isset($_GET['brand']) ? $_GET['brand'] : array();
	$brands = get_terms(array(
		'taxonomy'	 => 'brands',
		'orderby' => 'slug',
		'hide_empty' => true,
		'include'	=> $include_args,
		'parent' => 0,
		'meta_query' => array(
			'key' => 'region',
			'value' => strtoupper($_SESSION['region']),
			'compare' => 'LIKE'
		),
	));

	ob_start();

	echo '<div class="proform_products">';
		require_once __DIR__ . '/../template-parts/shortcode-products.php';
		require_once __DIR__ . '/../template-parts/shortcode-products-sidebar.php';
	echo '</div>';

	echo ob_get_clean();
}
add_shortcode('show-products-archive', 'archive_products_output');


function load_video_in_elementor_popup() {
	$videos = get_field('videos_repeater');

	if($videos) {
		if($videos[0]['videos_group']['video_description']) {
			$url = $videos[0]['videos_group']['video_youtube'];	
		}
		else {
			$url = '';
		}
	}
	else {
		$url = '';
	}
	return $url;
}
add_shortcode('load-video','load_video_in_elementor_popup');


function load_video_description_elementor_popup() {
	$videos = get_field('videos_repeater');
	if($videos) {
		if($videos[0]['videos_group']['video_description']) {
			$output = $videos[0]['videos_group']['video_description'];	
		}
		else {
			$output = '';
		}
	}
	else {
		$output = '';
	}
	return $output;
}
add_shortcode('load-video-description', 'load_video_description_elementor_popup');