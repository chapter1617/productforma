<?php
function count_distributors() {
	$count = wp_count_posts('distributors');
	$title = get_field('field_5f0d2907d6c9d', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['distributors_page_title_fr'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['distributors_page_title_sp'];
    } else {
    	$trans = $title['distributors_page_title_en'];
    }
	if($count) {
		$count = $count->publish . ' ' . $trans;
		// $count = $count * 4;
	}
	return $count;
}
add_shortcode('count-distributors', 'count_distributors');

function distributor_tel_url() {
	$tel = get_field('field_5d547005271e4');
	if($tel) {
		$telURL = 'tel:'.$tel;
	}
	else {
		$telURL = '';
	}
	return $telURL;
}
add_shortcode('distributor-tel-url', 'distributor_tel_url');

function distributor_page_title_trans() {
	$title = get_field('field_5f0d2907d6c9d', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['distributors_page_title_fr'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['distributors_page_title_sp'];
    } else {
    	$trans = $title['distributors_page_title_en'];
    }
    return $trans;
}
add_shortcode('distributor-page-title', 'distributor_page_title_trans');

function distributor_search_title_trans() {
	$title = get_field('field_5f0d2955d6ca1', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['d_search_title_fr'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['d_search_title_sp'];
    } else {
    	$trans = $title['d_search_title_en'];
    }
    return $trans;
}
add_shortcode('distributor-search-title', 'distributor_search_title_trans');

function distributor_search_our_database_trans() {
	$title = get_field('field_5f0d2a4ad3239', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['search_our_database_of_distributors_fr'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['search_our_database_of_distributors_sp'];
    } else {
    	$trans = $title['search_our_database_of_distributors_en'];
    }
    return $trans;
}
add_shortcode('distributor-search-database-title', 'distributor_search_our_database_trans');

function distributor_back_to_all_trans() {
	$title = get_field('field_5f0d2a79d323d', 'option');
	if($_SESSION['region'] == 'ca-fr') {
    	$trans = $title['back_to_all_distributors_fr'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
    	$trans = $title['back_to_all_distributors_sp'];
    } else {
    	$trans = $title['back_to_all_distributors_en'];
    }
    return $trans;
}
add_shortcode('distributor-back-to-all', 'distributor_back_to_all_trans');

function distributor_become_a_distributor_button() {
    $title = get_field('field_5fc95e3c13c4d', 'option');
    if($_SESSION['region'] == 'ca-fr') {
        $trans = $title['become_distributor_button_translations_fr'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
        $trans = $title['become_distributor_button_translations_sp'];
    } else {
        $trans = $title['become_distributor_button_translations_en'];
    }
    return $trans;
}
add_shortcode('become-a-distributor-button', 'distributor_become_a_distributor_button');

function become_distributor_page_link() {
    if ($_SESSION['region'] == 'ca-fr') {
        $link = get_permalink('16114');
    } elseif ( $_SESSION['region'] == 'us-sp' ) { 
        $link = get_permalink('16106');
    } else {
        $link = get_permalink('16104');
    }
    return $link;
}
add_shortcode('become-distributor-button-link', 'become_distributor_page_link');

function distributor_all_locations_title() {
    $title = get_field('field_5fc9687e0d90b', 'option');
    if($_SESSION['region'] == 'ca-fr') {
        $trans = $title['distributors_all_locations_title_fr'];
    } elseif ( $_SESSION['region'] == 'us-sp' ) {
        $trans = $title['distributors_all_locations_title_sp'];
    } else {
        $trans = $title['distributors_all_locations_title_en'];
    }
    return $trans;
}
add_shortcode('distributor-all-locations-title', 'distributor_all_locations_title');