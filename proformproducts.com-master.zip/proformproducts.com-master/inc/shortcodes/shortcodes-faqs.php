<?php
function show_faqs_archive() {
	$faqsPosts = get_posts( array (
		'post_type'		=>	'faqs',
		'post_status'	=>	'publish',
		'orderby'		=>	'date',
		'order'			=>	'ASC',
		'numberposts'	=>	-1,
	));
	
	$faqs = '<div class="faq-container">';
	if($faqsPosts) :
		foreach($faqsPosts as $faqItem) :
			$region_settings = get_field('region', $faqItem->ID);
			if(in_array_r(strtoupper($_SESSION['region']), $region_settings)) {
				$answer = get_field('answer_translations', $faqItem->ID);
				$titles = get_field('faq_title_translations', $faqItem->ID);
				if($answer) {
					if($_SESSION['region'] == 'ca-fr') {
						$faq_title = $titles['ca-fr_question'];
						$read_answer = 'Lire la réponse';
					}
					elseif($_SESSION['region'] == 'us-sp') {
						$faq_title = $titles['us-sp_question'];
						$read_answer = 'Leer respuesta';	
					}
					else {
						$faq_title = $faqItem->post_title;
						$read_answer = 'Read Answer';
					}
					$faqs .= '<a href="'.get_permalink($faqItem->ID).'" class="faq-item">';
					$faqs .= '<h4>'.$faq_title.'</h4>';
					$faqs .= '<span> <i class="fad fa-book-open"></i> '.$read_answer.'</span>';
					$faqs .= '</a>';
				}
			}
		endforeach;
	endif;
	$faqs .= '</div>';
	return $faqs;
}
add_shortcode('faq-archive', 'show_faqs_archive');

function count_faqs() {
	$faqsPosts = get_posts( array (
		'post_type'		=>	'faqs',
		'post_status'	=>	'publish',
		'orderby'		=>	'date',
		'order'			=>	'ASC',
		'numberposts'	=>	-1,
	));
	
	$faqs = '<div class="faq-container">';
	if($faqsPosts) :
		$i = 0;
		foreach($faqsPosts as $faqItem) :
			$region_settings = get_field('region', $faqItem->ID);
			if(in_array_r(strtoupper($_SESSION['region']), $region_settings)) {
				$i++;
			}
		endforeach;
	endif;
	// $count = wp_count_posts('faqs');
	$count = $i;
	if($_SESSION['region'] == 'ca-fr') {
		$faqs = 'Questions fréquemment posées';
	}	
	elseif($_SESSION['region'] == 'us-sp') {
		$faqs = 'Preguntas frecuentes';
	}
	else {
		$faqs = 'Frequently Asked Questions';
	}
	if($count) {
		// $count = '// ' . $count->publish . ' ' . $faqs;
		$count = '// ' . $count . ' ' . $faqs;
	}
	return $count;
}
add_shortcode('count-faqs', 'count_faqs');

function faq_page_description() {
	if($_SESSION['region'] == 'ca-fr') {
		$descrip = 'Vous trouverez ci-dessous une liste des questions fréquemment posées que nous avons collectées:';
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$descrip = 'A continuación se muestra una lista de las preguntas frecuentes que hemos recopilado:';
	}
	else {
		$descrip = 'Below is a list of the frequently asked questions we have collected:';
	}

	return $descrip;
}
add_shortcode('faq-page-description', 'faq_page_description');

function faq_title_translation() {
	$faq_title = get_field('faq_title_translations');
	if($_SESSION['region'] == 'ca-fr') {
		$faq_title_translation = $faq_title['ca-fr_question'];
	}	
	elseif($_SESSION['region'] == 'us-sp') {
		$faq_title_translation = $faq_title['us-sp_question'];
	}
	else {
		$faq_title_translation = get_the_title();
	}

	return $faq_title_translation;
}
add_shortcode('faq-title', 'faq_title_translation');

function faq_body_translation() {
	$faq_answer = get_field('answer_translations');
	if($_SESSION['region'] == 'ca-fr') {
		$faq_body = $faq_answer['ca-fr_answer'];
	}	
	elseif($_SESSION['region'] == 'us-sp') {
		$faq_body = $faq_answer['us-sp_answer'];
	}
	else {
		$faq_body = $faq_answer['en_answer'];
	}

	return $faq_body;
}
add_shortcode('faq-body', 'faq_body_translation');

function faq_back_to_trans() {
	if($_SESSION['region'] == 'ca-fr') {
		$back_to = 'Retour à toutes les FAQ';
	}	
	elseif($_SESSION['region'] == 'us-sp') {
		$back_to = 'Volver a todas las preguntas frecuentes';
	}
	else {
		$back_to = 'Back to All FAQs';
	}

	return $back_to;
}
add_shortcode('faq-back-to', 'faq_back_to_trans');