<?php
function show_resource_files() {
	$id = get_queried_object_id();
	$output = '';
	$redirect = get_field( 'redirect_on_language', $id );

	if($_SESSION['region'] == 'ca-en' or $_SESSION['region'] == 'ca-fr') {
		$rs_file_ca_en = get_field('resource_file_ca_en');
		if($rs_file_ca_en) {
			$tax = get_the_terms($id, 'type');
			$output .= '<div class="resource-file">';
			$output .= '<a target="_blank" href="'.$rs_file_ca_en['url'].'"><i class="fad fa-file-pdf"></i><span>'.get_the_title().'<br>'.$tax[0]->name.'<br>(Canada English)</span></a>';
			$output .= '</div>';
		} else {
			// $output .= get_the_title().' is not an available PDF resource in your country or language';
		}
		$rs_file_ca_fr = get_field('resource_file_ca_fr');
		if($rs_file_ca_fr) {
			$tax = get_the_terms($id, 'type');
			$output .= '<div class="resource-file">';
			$output .= '<a target="_blank" href="'.$rs_file_ca_fr['url'].'"><i class="fad fa-file-pdf"></i><span>'.get_the_title().'<br>'.$tax[0]->name.'<br>(Canada French)</span></a>';
			$output .= '</div>';
		} else {
			// $output .= get_the_title().' n\'est pas une ressource PDF disponible dans votre pays ou votre langue';
		}
		
	}
	if($_SESSION['region'] == 'us-en' or $_SESSION['region'] == 'int-en' or $_SESSION['region'] == 'us-sp') {
		$rs_file_us_en = get_field('resource_file_us_en');
		if($rs_file_us_en) {
			$tax = get_the_terms($id, 'type');
			$output .= '<div class="resource-file">';
			$output .= '<a target="_blank" href="'.$rs_file_us_en['url'].'"><i class="fad fa-file-pdf"></i><span>'.get_the_title().'<br>'.$tax[0]->name.'<br>(US English)</span></a>';
			$output .= '</div>';
		}
		else {
			// $output .= get_the_title().' is not an available resource in your country or language';
		}
		$rs_file_us_sp = get_field('resource_file_us_sp');
		if($rs_file_us_sp) {
			$tax = get_the_terms($id, 'type');
			$output .= '<div class="resource-file">';
			$output .= '<a target="_blank" href="'.$rs_file_us_sp['url'].'"><i class="fad fa-file-pdf"></i><span>'.get_the_title().'<br>'.$tax[0]->name.'<br>(US Spanish)</span></a>';
			$output .= '</div>';
		}
		else {
			// $output .= get_the_title().' no es un recurso PDF disponible en su país o idioma';
		}
	}

	if ( isset( $redirect[0] ) ):
		$output .= '<input type="hidden" id="redirect_on_language" value="redirect" />';
	else:
		$output .= '<input type="hidden" id="redirect_on_language" value="" />';
	endif;

	return $output;
}
add_shortcode('show-resources', 'show_resource_files');

// Get Translations for Resources Archive page
function resource_archive_translations_title() {
	$titleGroup = get_field('field_5e7506599f331', 'option'); //Title Group
	if($_SESSION['region'] == 'ca-fr') { 
		$title = '// '.$titleGroup['title-fr'];
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$title = '// '.$titleGroup['title-sp'];
	}
	else {
		$title = '// '.$titleGroup['title-en'];
		if($title) {
			$title = $title;
		}
		else {
			$title = '// Resources';
		}
	}

	return $title;
}
add_shortcode('resource-translation-title', 'resource_archive_translations_title');

function resource_archive_translations_content_title() {
	$contentGroup = get_field('field_5e7507139f339', 'option'); // Content Group
	if($_SESSION['region'] == 'ca-fr') { 
		$title = $contentGroup['content_title-fr'];
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$title = $contentGroup['content_title-sp'];
	}
	else {
		$title = $contentGroup['content_title-en'];
		if($title) {
			$title = $title;
		}
		else {
			$title = 'Search All Resources';
		}
	}

	return $title;
}
add_shortcode('resource-translation-content-title', 'resource_archive_translations_content_title');

function resource_archive_translations_content_line() {
	$contentGroup = get_field('field_5e7507139f339', 'option'); // Content Group
	if($_SESSION['region'] == 'ca-fr') { 
		$line = $contentGroup['content_line-fr'];
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$line = $contentGroup['content_line-sp'];
	}
	else {
		$line = $contentGroup['content_line-en'];
		if($line) {
			$line = $line;
		}
		else {
			$line = 'Find Safety Data Sheets, Tech Sheets, and other available documents on our products.';
		}
	}

	return $line;
}
add_shortcode('resource-translation-content-line', 'resource_archive_translations_content_line');

function resource_related_products() {
	$output = '';
	$products = get_posts( array (
		'post_type' 	=> 'products',
		'post_status'	=> 'publish',
		// 'meta_query'	=> array (
		// 	array (
		// 		'key'	=>  'field_5d55c9226bd4a',
		// 		'value'	=>	'"' . get_the_ID() . '"',
		// 		'compare'	=> 'LIKE'
		// 	)
		// )
	));
	foreach($products as $pro) {
		if(have_rows('variations', 6365)) :
			while(have_rows('variations', 6365)) : the_row();
				$resource = get_sub_field('part_number_related_resources');
				var_dump($resource);
				foreach($resource as $res) {
					
				}
			endwhile;
		endif;

	}
	return $output;
}
add_shortcode('show-related-resource-products', 'resource_related_products');

function count_resources() {
	$count = wp_count_posts('resources');
	$titleGroup = get_field('field_5e7506599f331', 'option');
	if($count) {
		$count = $count->publish;
		if($_SESSION['region'] == 'ca-fr') { 
			$t = '// '.$titleGroup['sub_title-fr'];
		}
		elseif($_SESSION['region'] == 'us-sp') {
			$t = '// '.$titleGroup['sub_title-sp'];
		}
		else {
			$t = '// '.$titleGroup['sub_title-en'];
			if($t) {
				$t = $t;
			}
			else {
				$t = '// PDF Documents';
			}
		}
		$count = '// ' . $count * 4 . ' ' .$t;	
	}
	else {
		$count = '';  
	}

	return $count;
}
add_shortcode('count-resources', 'count_resources');

function get_recently_updated_resources() {
	$latestResGroup = get_field('field_5e7508189f340', 'option'); // Latest Resources Group
	if($_SESSION['region'] == 'ca-fr') { 
		$t = $latestResGroup['latest_resource_title-fr'];
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$t = $latestResGroup['latest_resource_title-sp'];
	}
	else {
		$t = $latestResGroup['latest_resource_title-en'];
		if($t) {
			$t = $t;
		}
		else {
			$t = 'Latest Resources Updated';
		}
	}
	if($_SESSION['region'] == 'ca-fr') {
		$resource_file = 'resource_file_ca_fr';
	} elseif ($_SESSION['region'] == 'us-en') {
		$resource_file = 'resource_file_us_en';
	} elseif ($_SESSION['region'] == 'us-sp') {
		$resource_file = 'resource_file_us_sp';
	} else {
		$resource_file = 'resource_file_ca_en';
	}
	$recent = get_posts( array (
		'post_type'	=> 'resources',
		'numberposts'	=> 6,
		'post_status'	=> 'publish',
		'orderby'		=> 'modified',
		'order'			=> 'DESC',
		'meta_key'		=> $resource_file,
		'meta_value'	=> ' ',
		'meta_compare'	=> '!=',
	));



	$count = count($recent);
	if($count < 7) {
		$justification = 'flex-centered';
	} else {
		$justification = 'flex-left';
	}
	$output = '<h4 class="resource-title-h2">'.$t.'</h4>';
	$output .= '<div class="resource-container '.$justification.'">';
	foreach ($recent as $r) {
		$output .= '<div class="resource-file">';
		$output .= '<a href="'.get_permalink($r->ID).'"><i class="fad fa-file-pdf"></i><span><b>'.get_the_title($r->ID).'</b><br></span><span class="resource-updated">'.get_the_modified_date('M j, Y',$r->ID).'</span></a>';
		$output .= '</div>';
	}
	$output .= '</div>';
	return $output;
}
add_shortcode('recently-updated-resources', 'get_recently_updated_resources');

function single_resource_sub_title() {
	$group = get_field('field_5e754c2d970ce', 'option');
	if($_SESSION['region'] == 'ca-fr') {
		$t = '// '.$group['sub_title-fr'];
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$t = '// '.$group['sub_title-sp'];
	}
	else {
		$t = '// '.$group['sub_title-en'];
		if($t) {
			$t = $t;
		}
		else {
			$t = '// Ressource PDF d\'Pro Form';
		}
	}
	return $t;
}
add_shortcode('single-resource-sub-title', 'single_resource_sub_title');

function single_resource_download_instructions() {
	$group = get_field('field_5e754d17970d2', 'option');
	if($_SESSION['region'] == 'ca-fr') {
		$t = $group['pdf_download_instructions-fr'];
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$t = $group['pdf_download_instructions-sp'];
	}
	else {
		$t = $group['pdf_download_instructions-en'];
		if($t) {
			$t = $t;
		}
		else {
			$t = 'Click on a file below to download or open the PDF:';
		}
	}
	return $t;
}
add_shortcode('single-resource-download-instructions','single_resource_download_instructions');

function single_resource_search_database_translations() {
	$group = get_field('field_5e754dd3abce8', 'option');
	if($_SESSION['region'] == 'ca-fr') {
		$t = $group['search_our_database_of_resources-fr'];
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$t = $group['search_our_database_of_resources-sp'];
	}
	else {
		$t = $group['search_our_database_of_resources-en'];
		if($t) {
			$t = $t;
		}
		else {
			$t = 'Search Our Database of Resources';
		}
	}
	return $t;
}
add_shortcode('single-resource-search-database-translation','single_resource_search_database_translations');

function single_resource_back_to_all() {
	$group = get_field('field_5e7550f882dbb', 'option');
	if($_SESSION['region'] == 'ca-fr') {
		$t = $group['back_to_all_resources-fr'];
	}
	elseif($_SESSION['region'] == 'us-sp') {
		$t = $group['back_to_all_resources-sp'];
	}
	else {
		$t = $group['back_to_all_resources-en'];
		if($t) {
			$t = $t;
		}
		else {
			$t = 'Back to All Resources';
		}
	}
	return $t;
}
add_shortcode('single-resource-back-to-all','single_resource_back_to_all');