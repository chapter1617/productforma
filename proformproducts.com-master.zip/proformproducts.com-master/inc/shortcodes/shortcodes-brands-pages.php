<?php 
// Get Products for Specific Brand
function brands_show_products() {
	// $pageID = get_queried_object_id(); $output = $pageID;
	// $brands = get_terms( array (
	// 	'taxonomy'	=> 'brands',
	// ));
	// foreach ($brands as $brand) {
	// 	$rel = get_field('related_page', $brand->term_id);
	// 	var_dump($rel);
	// 	if($pageID == $rel) {
	// 		$brandID = $brand->term_id;
	// 	}
	// }
	$lang = $_SESSION['region'];
	$output = '';
	$products = get_field('brand_featured_products');
	if($products) {
		$output .= '<div class="product-grid-container brand-product-grid-container">';
		foreach($products as $cps) { // loop repeater
			foreach($cps as $cp) { // post object
				$variations = get_field('product_details', $cp->ID);
				$output .= '<div class="product-grid-item product-'.$cp->ID.'">';
				$output .= '<a href="'.get_permalink($cp->ID).'">';
					$output .= '<div class="image-wrapper">';
					// Get first variation
					$imageID = $variations[0]['image']['ID'];
					$image = wp_get_attachment_image_src( $imageID, 'medium' );
					// $output .= var_dump($image);
					$mainImg = get_field('main_image', $cp->ID);
					if($mainImg) {
						$output .= wp_get_attachment_image( $mainImg['ID'], 'medium');
					}
					elseif($image) {
						if($image[2] <= 600) {
							$width = 'max-width:380px';
							$height = 'auto';
						}
						elseif ($image[2] >= 600 ) {
							$width = 'max-width:auto';
							$height = 'max-height:300px';	
						}
						$output .= '<img class="product-image" src="'.$image[0].'">';
					}
					else {
						$output .= '<i class="fal fa-images"></i>';
					}
					$output .= '</div>';
					$output .= '<div class="title-wrapper">';
						$product_name = get_field('product_names_group', $cp->ID);
						if($product_name) {
							$output .= '<h4>'.$product_name[$lang.'_product_name'].'</h4>';
						}
						else {
							$output .= '<h4>'.$cp->post_title.'</h4>';
						}
					$output .= '</div>';
					$output .= '<div class="part-number-wrapper">';
						$output .= '<div class="part-number-label">Part #</div>';
						$output .= '<div class="product-part-numbers">';
							$output .= '<div class="main-part-number">'.$variations[0]['part_number'].'</div>';
							$cv = count($variations);
							if($cv > 1) {
								$cvv = $cv - 1;
								$output .= '<div class="additional-part-numbers">';
								$output .= '+ ' .$cvv.' Options';
								$output .= '</div>';
							}
						$output .= '</div>';
					$output .= '</div>';
				$output .= '</a>';
				$output .= '</div>';
			}
		}
		$output .= '</div>';
	}
	else {
		if( current_user_can('editor') || current_user_can('administrator') ) {
			$output = 'Please add featured products by going to <a href="'.get_edit_post_link(get_the_ID()).'">edit</a>.';	
		}
		else {
			$output = 'No featured products currently listed.';
		}
		
	}
	return $output;
}
add_shortcode('show-brand-products', 'brands_show_products');