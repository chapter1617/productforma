<?php
function output_representatives_canada() {
	$rep_cats = get_terms(
		array (
			'taxonomy'	=> 'rep-region',
			'hide_empty'=> 'true',
		)
	);
	// var_dump($rep_cats);
	$output = '<div class="representative-container">';
	foreach($rep_cats as $rc) {
		$region = get_field('region', 'rep-region_'.$rc->term_id);
		if(in_array_r(strtoupper($_SESSION['region']), $region)) :
			$output .= '<div class="rep-region">';
				$reps = get_posts( array (
					'post_type' => 'representatives',
					'status'	=> 'publish',
					'tax_query' => array (
						array (
							'taxonomy'	=> 'rep-region',
							'field'		=> 'term_id',
							'terms'		=> $rc->term_id,
						)
					)
				));
				$output .= '<h2>'.$rc->name.'</h2>';
				foreach($reps as $rep) {
					$area 		= get_field('area', $rep->ID);
					$agency 	= get_field('company', $rep->ID);
					$main_ph 	= get_field('main_phone', $rep->ID);
					$office_ph 	= get_field('office_phone', $rep->ID);
					$cell_ph 	= get_field('cell_phone', $rep->ID);
					$email 		= get_field('email', $rep->ID);
					$address 	= get_field('address', $rep->ID);
					$fax 	 	= get_field('fax', $rep->ID);
					if($area) {
						$area = ' ('.$area.')';
					} else {
						$area = '';
					}
					$output .= '<div class="rep-info">';
						$output .= '<h3>'.get_the_title($rep->ID).$area.'</h3>';
						if($agency) {$output .= '<span class="company">'.$agency.'</span>';}
						if($address) {$output .= '<span class="address">'.$address.'</span>';}
						if($main_ph) {$output .= '<span class="phone-main">Ph: <a href="tel:'.$main_ph.'">'.$main_ph.'</a></span>';}
						if($office_ph) {$output .= '<span class="phone-office">Ph: <a href="tel:'.$office_ph.'">'.$office_ph.'</a></span>';}
						if($cell_ph) {$output .= '<span class="phone-cell">Cell: <a href="tel:'.$cell_ph.'">'.$cell_ph.'</a></span>';}
						if($fax) {$output .= '<span class="fax">Fax: '.$fax.'</span>';}
						if($email) {$output .= '<span class="email">Email: <a href="mailto:'.$email.'">'.$email.'</a></span>';}
					$output .= '</div>';
				}
			$output .= '</div>'; //.rep-region
		else :
		endif;
	}
	$output .= '</div>';

	// $output = 'Test';

	return $output;
}
add_shortcode('rep-contacts', 'output_representatives_canada');

function change_rep_link_en() {
	if($_SESSION['region'] == 'ca-en') {
		$output = 'https://proformproducts.com/ca/en/find-a-representative/';
	} else {
		$output = 'https://proformproducts.com/us/en/find-a-representative/';
	}

	return $output;
}
add_shortcode('change-rep-link', 'change_rep_link_en');