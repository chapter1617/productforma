<?php

// Populate contact form with products
// add_filter( 'gform_pre_render_1', 'populate_products' );
// add_filter( 'gform_pre_validation_1', 'populate_products' );
// add_filter( 'gform_pre_submission_filter_1', 'populate_products' );
// add_filter( 'gform_admin_pre_render_1', 'populate_products' );
// function populate_products( $form ) {
 
//     foreach ( $form['fields'] as &$field ) {
 
//         if ( $field->type != 'select' || strpos( $field->cssClass, 'populate-products' ) === false ) {
//             continue;
//         }
//         $products = get_posts('post_type=products&post_status=publish&numberposts=-1');
 
//         $choices = array();
 
//         foreach ( $products as $product ) {
//             $choices[] = array( 'text' => $product->post_title, 'value' => $product->post_title );
//         }
 
//         // update 'Select a Post' to whatever you'd like the instructive option to be
//         $field->placeholder = 'Select a Product';
//         $field->choices = $choices;
 
//     }
 
//     return $form;
// }

// Translate contact form if language is different
add_filter( 'gform_pre_render_1', 'translate_form_labels' );
add_filter( 'gform_pre_submission_filter_1', 'translate_form_labels' );
function translate_form_labels($form) {
  if($_SESSION['region'] == 'us-sp') {
    $name = 'Nombre';
    $first_name = 'Nombre de pila';
    $last_name = 'Apellido';
    $company = 'Empresa';
    $email = 'Correo electrónico';
    $phone = 'Teléfono';
    $interest = 'Estoy interesado en los siguientes productos';
    $request = 'Mi solicitud está relacionada con';
      $support = array('text' => 'Apoyo', 'value' => 'Support');
      $sales = array('text' => 'Ventas', 'value' => 'Sales');
      $product_info = array('text' => 'Información del producto', 'value' => 'Product Info');
      $tech_info = array('text' => 'Información técnica', 'value' => 'Technical Info');
      $other = 'Otro';
    $message = 'Mensaje';
    $captcha = 'Captcha';
    $send = 'Enviar';
  }
  elseif($_SESSION['region'] == 'ca-fr') {
    $name = 'Nom';
    $first_name = 'Prénom';
    $last_name = 'Nom de famille';
    $company = 'Compagnie';
    $email = 'Email';
    $phone = 'Téléphone';
    $interest = 'Je suis intéressé par les produits suivants';
    $request = 'Ma demande concerne';
      $support = array('text' => 'Soutien', 'value' => 'Support');
      $sales = array('text' => 'Ventes', 'value' => 'Sales');
      $product_info = array('text' => 'Information sur le produit', 'value' => 'Product Info');
      $tech_info = array('text' => 'Info technique', 'value' => 'Technical Info');
      $other = 'Autre';
    $message = 'Message';
    $captcha = 'Captcha';
    $send = 'Envoyer';
  }
  else {
    $name = 'Name';
    $first_name = 'First';
    $last_name = 'Last';
    $company = 'Company';
    $email = 'Email';
    $phone = 'Phone';
    $interest = 'I am interested in the following products:';
    $request = 'My request is regarding';
      $support = array('text' => 'Support', 'value' => 'Support');
      $sales = array('text' => 'Sales', 'value' => 'Sales');
      $product_info = array('text' => 'Product Info', 'value' => 'Product Info');
      $tech_info = array('text' => 'Technical Info', 'value' => 'Technical Info');
      $other = 'Other';
    $message = 'Message';
    $captcha = 'Captcha';
    $send = 'Send';
  }
  $requests_r = array($support, $sales, $product_info, $tech_info);
  foreach ( $form['fields'] as $field ) {
    if('name' === $field['type'] && $field['id'] == 1) {
      $field['label'] = $name;
      $inputs = $field->inputs;
      $inputs[1]['placeholder'] = $first_name;
      $inputs[3]['placeholder'] = $last_name;
      $field->inputs = $inputs;
      // echo '<pre>';
      // var_dump($field);
      // echo '</pre>';
    }
    if('text' === $field['type'] && $field['id'] == 2) {
      $field['label'] = $company;
    }
    if('email' === $field['type'] && $field['id'] == 3) {
      $field['label'] = $email;
    }
    if('phone' === $field['type'] && $field['id'] == 4) {
      $field['label'] = $phone;
    }
    if('text' === $field['type'] && $field['id'] == 10) {
      $field['label'] = $interest;
    }
    if('radio' === $field['type'] && $field['id'] == 8) {
      $field['label'] = $request;
      $choices = array();
      foreach($requests_r as $rr) {
        $choices[] = array('text' => $rr['text'], 'value' => $rr['value']);
      }
      $field->choices = $choices;
    }
    if('textarea' === $field['type'] && $field['id'] == 6) {
      $field['label'] = $message;
    }
    if('captcha' === $field['type'] && $field['id'] == 9) {
      $field['label'] = $captcha;
    }
  }
  $form['button']['text'] = $send;
  return $form;
}

// Translate distributor application form if language is different
add_filter( 'gform_pre_render_2', 'translate_distributor_form_labels' );
add_filter( 'gform_pre_submission_filter_2', 'translate_distributor_form_labels' );
function translate_distributor_form_labels($form) {
  if($_SESSION['region'] == 'us-sp') {
    $name = 'Nombre completo';
    $first_name = 'Nombre de pila';
    $last_name = 'Apellido';
    $address = 'Dirección';
    $street_address = 'Dirección de calle';
    $address_line_2 = 'Línea de dirección 2';
    $city = 'Ciudad';
    $state = 'Estado';
    $country = "Pais";
    $postal_code = 'Código postal';
    $company = 'Nombre de la empresa';
    $email = 'Email';
    $phone = 'Número de teléfono';
    $type_of_business = 'Tipo de negocio';
    	$warehouse 	= array('text' => 'Depósito de almacenamiento', 'value' => 'Warehouse');
    	$jobbers 	= array('text' => 'Tienda mayorista', 'value' => 'Jobbers store');
    	$bodyshop	= array('text' => 'Taller de carrocería', 'value' => 'Bodyshop');
    	$individual = array('text' => 'Individual', 'value' => 'Individual');
    $position = 'Posición';
    	$buyer			= array('text' => 'Comprador', 'value' => 'Buyer');
    	$sales_rep 		= array('text' => 'Representante de ventas', 'value' => 'Sales Rep');
    	$bodyman 		= array('text' => 'Hojalatero', 'value' => 'Bodyman');
    	$do_it_yourself = array('text' => 'Hágalo usted mismo', 'value' => 'Do it yourself');
    $banner = 'Grupo de compra / Banner';
    $currently_purchasing_from = 'Actualmente comprando en';
    $annual_purchases = 'Compras netas anuales';
    $supplier = 'Nombre del proveedor y número de pieza';
    $question = 'Tu pregunta';
    $message = 'comentarios';
    $captcha = 'Captcha';
    $send = 'Enviar';
  }
  elseif($_SESSION['region'] == 'ca-fr') {
    $name = 'Nom';
    $first_name = 'Prénom';
    $last_name = 'Nom de famille';
    $address = 'adresse';
    $street_address = 'Adresse de rue';
    $address_line_2 = 'Adresse Ligne 2';
    $city = 'Ville';
    $state = 'Province';
    $country = "Pays";
    $postal_code = 'code postal';
    $company = 'Compagnie';
    $email = 'Email';
    $phone = 'Téléphone';
    $type_of_business = 'Type de commerce';
    	$warehouse 	= array('text' => 'Entrepôt', 'value' => 'Warehouse');
    	$jobbers 	= array('text' => 'Magasin Jobbers', 'value' => 'Jobbers store');
    	$bodyshop	= array('text' => 'carrosserie', 'value' => 'Bodyshop');
    	$individual = array('text' => 'individuel', 'value' => 'Individual');
    $position = 'Posición';
    	$buyer			= array('text' => 'acheteur', 'value' => 'Buyer');
    	$sales_rep 		= array('text' => 'Représentant commercial', 'value' => 'Sales Rep');
    	$bodyman 		= array('text' => 'carrossier', 'value' => 'Hojalatero');
    	$do_it_yourself = array('text' => 'Fais le toi-même', 'value' => 'Do it yourself');
    $banner = 'Groupe d\'achat / bannière';
    $currently_purchasing_from = 'Achat actuel de';
    $annual_purchases = 'Achats nets annuels';
    $supplier = 'Nom du fournisseur et numéro de pièce';
    $question = 'Ta question';
    $message = 'commentaires';
    $captcha = 'Captcha';
    $send = 'Envoyer';
  }
  else {
    $name = 'Name';
    $first_name = 'First';
    $last_name = 'Last';
    $address = 'Address';
    $street_address = 'Street Address';
    $address_line_2 = 'Address Line 2';
    $city = 'City';
    if($_SESSION['region'] == 'ca-en') {
    	$state = 'Province';
    	$postal_code = 'Postal Code';
    } else {
    	$state = 'State';
    	$postal_code = 'Zip Code';
    }
    $country = "Country";
    $company = 'Company';
    $email = 'Email';
    $phone = 'Phone';
    $type_of_business = 'Type of Business';
    	$warehouse 	= array('text' => 'Warehouse', 'value' => 'Warehouse');
    	$jobbers 	= array('text' => 'Jobbers store', 'value' => 'Jobbers store');
    	$bodyshop	= array('text' => 'Bodyshop', 'value' => 'Bodyshop');
    	$individual = array('text' => 'Individual', 'value' => 'Individual');
    $position = 'Position';
    	$buyer			= array('text' => 'Buyer', 'value' => 'Buyer');
    	$sales_rep 		= array('text' => 'Sales Rep', 'value' => 'Sales Rep');
    	$bodyman 		= array('text' => 'Bodyman', 'value' => 'Bodyman');
    	$do_it_yourself = array('text' => 'Do it yourself', 'value' => 'Do it yourself');
    $banner = 'Buying Group / Banner';
    $currently_purchasing_from = 'Currently Purchasing From';
    $annual_purchases = 'Annual Net Purchases';
    $supplier = 'Supplier Name and Part Number';
    $question = 'Your Question';
    $message = 'Comments';
    $captcha = 'Captcha';
    $send = 'Send';
  }
  $type_of_business_array = array($warehouse, $jobbers, $bodyshop, $individual);
  $position_array = array($buyer, $sales_rep, $bodyman, $do_it_yourself);
  foreach ( $form['fields'] as $field ) {
    if('name' === $field['type'] && $field['id'] == 1) {
      $field['label'] = $name;
      $inputs = $field->inputs;
      $inputs[1]['placeholder'] = $first_name;
      $inputs[3]['placeholder'] = $last_name;
      $field->inputs = $inputs;
    }
    if('address' === $field['type'] && $field['id'] == 2) {
      $field['label'] = $address;
      $inputs = $field->inputs;
      $inputs[0]['placeholder'] = $street_address;
      $inputs[1]['placeholder'] = $address_line_2;
      $inputs[2]['placeholder'] = $city;
      $inputs[3]['placeholder'] = $state;
      $inputs[4]['placeholder'] = $postal_code;
      $inputs[5]['placeholder'] = $country;
      $field->inputs = $inputs;
      // echo '<pre>';
      // var_dump($field);
      // echo '</pre>';
    }
    if('phone' === $field['type'] && $field['id'] == 14) {
      $field['label'] = $phone;
    }
    if('email' === $field['type'] && $field['id'] == 3) {
      $field['label'] = $email;
    }
    if('text' === $field['type'] && $field['id'] == 4) {
      $field['label'] = $company;
    }
    if('select' === $field['type'] && $field['id'] == 5) {
      $field['label'] = $type_of_business;
      $choices = array();
      foreach($type_of_business_array as $tb) {
        $choices[] = array('text' => $tb['text'], 'value' => $tb['value']);
      }
      $field->choices = $choices;
    }
    if('select' === $field['type'] && $field['id'] == 6) {
      $field['label'] = $position;
      $choices = array();
      foreach($position_array as $pa) {
        $choices[] = array('text' => $pa['text'], 'value' => $pa['value']);
      }
      $field->choices = $choices;
    }
    if('text' === $field['type'] && $field['id'] == 7) {
      $field['label'] = $banner;
    }
    if('text' === $field['type'] && $field['id'] == 8) {
      $field['label'] = $currently_purchasing_from;
    }
    if('text' === $field['type'] && $field['id'] == 9) {
      $field['label'] = $annual_purchases;
    }
    if('text' === $field['type'] && $field['id'] == 10) {
      $field['label'] = $supplier;
    }
    if('text' === $field['type'] && $field['id'] == 11) {
      $field['label'] = $question;
    }
    if('textarea' === $field['type'] && $field['id'] == 12) {
      $field['label'] = $message;
    }
    if('captcha' === $field['type'] && $field['id'] == 15) {
      $field['label'] = $captcha;
    }
  }
  $form['button']['text'] = $send;
  return $form;
}