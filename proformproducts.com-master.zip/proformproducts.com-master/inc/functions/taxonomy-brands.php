<?php 

add_action( 'init', 'custom_product_taxonomy_brands', 0 );
 
function custom_product_taxonomy_brands() {
 
  $labels = array(
    'name' => _x( 'Brands', 'taxonomy general name' ),
    'singular_name' => _x( 'Brand', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Brands' ),
    'all_items' => __( 'All Brands' ),
    'parent_item' => __( 'Parent Brand' ),
    'parent_item_colon' => __( 'Parent Brand:' ),
    'edit_item' => __( 'Edit Brand' ), 
    'update_item' => __( 'Update Brand' ),
    'add_new_item' => __( 'Add New Brand' ),
    'new_item_name' => __( 'New Brand Name' ),
    'menu_name' => __( 'Brands' ),
  ); 	
 
  register_taxonomy('brands',
  	array('products'), 
  		array(
  			'public'			      => true,
		    'hierarchical' 		  => true,
		    'labels' 			      => $labels,
		    'show_ui' 			    => true,
		    'show_admin_column' => true,
		    'show_in_rest' 		  => true,
		    'show_in_quick_edit'=> true,
		    'publicly_queryable'=> true,
		    'query_var' 		    => true,
		    'rewrite' 			    => array( 'slug' => 'brand' ),
	  )
  	);
}