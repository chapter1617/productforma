<?php 

add_action( 'init', 'custom_product_taxonomy_markets', 0 );
 
function custom_product_taxonomy_markets() {
 
  $labels = array(
    'name' => _x( 'Markets', 'taxonomy general name' ),
    'singular_name' => _x( 'Market', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Markets' ),
    'all_items' => __( 'All Markets' ),
    'parent_item' => __( 'Parent Market' ),
    'parent_item_colon' => __( 'Parent Market:' ),
    'edit_item' => __( 'Edit Market' ), 
    'update_item' => __( 'Update Market' ),
    'add_new_item' => __( 'Add New Market' ),
    'new_item_name' => __( 'New Market Name' ),
    'menu_name' => __( 'Markets' ),
  ); 	
 
  register_taxonomy('markets',
  	array('products'), 
  		array(
  			'public'			      => true,
		    'hierarchical' 		  => true,
		    'labels' 			      => $labels,
		    'show_ui' 			    => true,
		    'show_admin_column' => true,
		    'show_in_rest' 		  => true,
		    'show_in_quick_edit'=> true,
		    'publicly_queryable'=> true,
		    'query_var' 		    => true,
		    'rewrite' 			    => array( 'slug' => 'market' ),
	  )
  	);
}