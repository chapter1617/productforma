<?php

add_action('wp_ajax_myfilter', 'product_filtering_by_category'); // wp_ajax_{ACTION HERE} 
add_action('wp_ajax_nopriv_myfilter', 'product_filtering_by_category');

function product_filtering_by_category() {
	$args = array(
		'orderby' => 'date', // we will sort posts by date
		'order'	=> $_POST['date'] // ASC or DESC
	);

	// for taxonomies / categories
	if( isset( $_POST['categoryfilter'] ) )
		$args['tax_query'] = array(
			array(
				'taxonomy' => 'category',
				'field' => 'id',
				'terms' => $_POST['categoryfilter']
			)
		);
	$query = new WP_Query( $args );

	
}