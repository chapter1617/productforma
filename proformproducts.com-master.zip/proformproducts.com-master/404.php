<?php get_header(); ?>
	
	<h1>This page could not be found.</h1>
		
<?php get_footer(); ?>